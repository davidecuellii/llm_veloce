---
type: playbook
tags: [agenzia, brand, identita]
created: 2026-09-01
updated: 2026-09-01
---

# Identità — Veloce Digital

## Chi siamo

**Veloce Digital** è un'agenzia creativa social-first con base nell'area di
Brescia/Montichiari, specializzata in short-form video, TikTok, Instagram Reels,
format virali, video commerciali, contenuti nightlife/eventi, TikTok Shop e social
branding.

**Team**:
- **Davide Cuelli** — **ideatore e fondatore**. E' il punto di partenza dell'agenzia e
  l'unico referente contrattuale verso i clienti (art. 2 del contratto Teresa). Mantiene
  anche una presenza personale da creator (650k+ follower complessivi tra TikTok,
  Instagram, YouTube), usata come proof of concept per l'agenzia. Fattura personalmente in
  regime forfettario (non soggetto IVA, art. 1 commi 54-89 L. 190/2014), non tramite
  l'entità Veloce Digital. CF `CLLDVD01M12D284J`, Via Paolo Borsellino 5, Montichiari (BS).
- **Matteo Campanella** — graphic designer e visual specialist, **subentrato come socio sul
  cliente [[../clients/barbar/overview|BarBar]]**. Lo split 50/50 degli utili con Davide
  citato nella fonte storica va riletto alla luce dell'assetto per cliente descritto sotto.
- **Gabriel Palamini** — marketing e advertising, **socio sul cliente
  [[../clients/teresa-srl/overview|Teresa Chiuduno]]**, dove co-fattura come collaboratore
  co-fatturante (regime forfettario, CF `PLMGRL01S19Z602I`). Ha preparato il modulo di
  onboarding clienti, vedi [[../playbook/outreach#Onboarding del cliente acquisito]].

### Assetto attuale dei soci

I soci sono associati **per cliente, non per funzione**. Oggi i clienti attivi sono due
(BarBar con Matteo, Teresa Chiuduno con Gabriel) e di conseguenza i ruoli sono ancora misti e
intercambiabili: con questo volume non ha senso una divisione rigida.

**Direzione voluta**: arrivare ad avere tutti e tre su lavori diversi, cioe' ogni socio
autonomo su clienti propri. E' anche la risposta al rischio di dipendenza dal founder: finche'
Davide e' contemporaneamente strategia, idee, vendita, shooting, controllo editing e rapporto
col cliente, il numero massimo di clienti gestibili resta basso. La leva per uscirne e' la
standardizzazione dei processi, vedi [[processi-tool]] e [[../playbook/outreach]].

**Fiscale**: INPS Commercianti, riduzione contributiva del 50% attiva (Legge
207/2024); i contributi pieni riprendono dal 2028. Vedi [[pricing]] per come questo
impatta il calcolo del netto.

## Brand identity

- Logo: `logoVeloce2024v4.png`
- **Palette scura (primaria)**:
  - Sfondo: `#202020`
  - Testo/elementi chiari: `#D6D6D6`
  - Accento giallo limone: `#FFEE32`
- **Palette light (quando serve sfondo chiaro)**:
  - Sfondo: `#F5F5F5` (preferito a `#FFFFFF`, meno aggressivo)
  - Titoli: `#202020`
  - Corpo: `#3A3A3A`
  - Testo secondario: `#6B6B6B`
  - Accento: `#D4C000` (giallo scurito ~20%, leggibile su bianco)
  - Il giallo puro `#FFEE32` va usato **solo** su badge/etichette con sfondo scuro,
    mai come testo su bianco
- Font: sans-serif bold per titoli (Inter, Helvetica Neue o simili), peso regolare
  per il corpo
- Tagline: **"I tuoi social in corsa con Veloce."**
- Contatti: WhatsApp 331 204 3165, Instagram [@veloceit](https://instagram.com/veloce_it)
- Preferenze di design: sfondo scuro (nero/bianco/giallo), layout minimale, logo in
  alto a sinistra, data in alto a destra, footer con nome di Davide e @veloceit.
  Niente linguaggio corporate (es. no "Q2 2026"), niente framing da agenzia gonfiata;
  tono da studio creativo serio e professionale.

## Regole di scrittura tassative

- **Mai** usare il trattino lungo (em dash —) nei testi in italiano. Solo
  punteggiatura standard italiana (virgole, punti, parentesi, due punti). Questa
  regola vale anche per tutto ciò che scrivo io (l'agente) nel wiki e in qualsiasi
  output destinato a Davide o ai clienti.
- Tutto il lavoro si svolge in italiano, con vocabolario di settore fluente: hook,
  retention, pattern interrupt, retainer, tier, funnel, ManyChat, ADV, UGC, CTR,
  obiettivo operativo, ecc.

## Promemoria operativo permanente

Ogni volta che si prepara un prompt per Claude Design per un preventivo/documento
Veloce Digital, **ricordare esplicitamente a Davide di allegare fisicamente il file
`logoVeloce2024v4.png`** insieme al testo del prompt. Il solo testo non basta, senza
il file il logo non viene mai inserito. Vedi [[processi-tool]] per il resto dello
stack di strumenti.

## Collegamenti

[[posizionamento]] · [[pricing]] · [[processi-tool]]
