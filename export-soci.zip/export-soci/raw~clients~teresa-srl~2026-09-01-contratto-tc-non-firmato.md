# Teresa S.r.l. — Contratto di servizi "Piano Completo Start" (versione non firmata)

> **Fonte**: `allegati/2026-09-01-contratto-tc-non-firmato.pdf`, 6 pagine, consegnato da
> Davide il 01/09/2026. Trascrizione integrale fedele. Documento **non firmato**: i campi
> sede legale, P.IVA, referente, email, data e luogo sono ancora vuoti.
> Il contratto e' il riferimento normativo per la garanzia 1M views, non la sintesi.

---

## 1. Parti del contratto

**Fornitore**: Davide Cuelli, libero professionista operante con il marchio commerciale
Veloce Digital. CF `CLLDVD01M12D284J`. Via Paolo Borsellino 5, 25018 Montichiari (BS).
Regime forfettario ex art. 1 commi 54-89 L. 190/2014. WhatsApp 331 204 3165, @veloce_it.

**Collaboratore co-fatturante**: Gabriel Palamini, libero professionista.
CF `PLMGRL01S19Z602I`. Via Piane 17, 24020 Gorno (BG). Regime forfettario ex art. 1
commi 54-89 L. 190/2014.

**Cliente**: Teresa S.r.l. (sede legale, P.IVA, referente ed email da compilare).

## 2. Oggetto del contratto

Pacchetto **Piano Completo Start**, per la gestione e sviluppo della presenza digitale e
commerce del brand Teresa.

Il Fornitore agisce attraverso Davide Cuelli, responsabile del progetto e **unico referente
contrattuale** del Cliente. Parte dei corrispettivi potra' essere fatturata da Gabriel
Palamini, ferma restando la responsabilita' di coordinamento di Davide. La ripartizione
della fatturazione puo' essere concordata tra le Parti o comunicata preventivamente al
Cliente, fermo restando che **l'importo complessivo mensile non puo' superare euro 2.100,00**.

## 3. Servizi inclusi

### 3.1 Setup iniziale (una tantum, incluso nel piano)

- Realizzazione e-commerce su piattaforma Shopify, configurato da zero
- Attivazione TikTok Shop collegato allo Shopify
- Integrazione con gestionale Danea EasyFatt (modalita' da definire in base alla versione in
  uso: nativa per edizione Enterprise/Enterprise One, tramite connettore terze parti per
  edizioni inferiori)
- Lancio iniziale con 50 articoli selezionati (beauty, profumi, skincare coreana), con
  caricamento progressivo fino a 300 articoli totali nei mesi successivi
- Strategia di lancio con contenuti hype pre-apertura

### 3.2 Servizi ricorrenti mensili

- 12 contenuti video verticali al mese finalizzati alla vendita
- 1 sessione di shooting al mese presso il punto vendita o location concordata
- Piano editoriale mensile con copy, hook e guide per TikTok Shop
- Report mensile sui dati di vendita con ottimizzazioni
- Risposta del Fornitore al Cliente entro 24 ore lavorative (lunedi-venerdi, esclusi festivi)

### 3.3 Obiettivo operativo

Il Fornitore si impegna a lavorare con l'obiettivo di raggiungere **1.000.000 di
visualizzazioni organiche cumulative tra Instagram e TikTok entro 90 giorni dal primo
contenuto pubblicato**.

Perimetro di calcolo:
- solo contenuti pubblicati sui profili ufficiali del Cliente
- solo contenuti realizzati dal Fornitore nell'ambito del Contratto
- solo nel periodo di 90 giorni decorrente dalla pubblicazione del primo contenuto
- solo visualizzazioni **organiche** su Instagram e TikTok
- **esclusi**: altri canali, campagne pubblicitarie a pagamento, contenuti non realizzati dal
  Fornitore

In caso di mancato raggiungimento entro i 90 giorni, il Fornitore eroga senza costi
aggiuntivi un **supporto esteso fino al raggiungimento**, a condizione che il Cliente abbia
rispettato **tutte** le seguenti condizioni durante il periodo contrattuale:
- approvazione dei contenuti entro 48 ore dalla ricezione
- rispetto del calendario di pubblicazione concordato
- mantenimento del controllo creativo del Fornitore su hook, struttura e formato dei contenuti

Il mancato rispetto anche di una sola condizione esonera il Fornitore dall'obbligo di
supporto esteso gratuito. **L'obiettivo e' operativo e non costituisce garanzia contrattuale
di risultato.**

### 3.4 Costi inclusi ed esclusi

Il corrispettivo mensile **include**, per il primo anno di rapporto, i costi ordinari
relativi a Shopify, eventuali app/plugin necessari allo svolgimento ordinario del progetto e
dominio. Per costi ordinari si intendono esclusivamente i costi necessari per l'avvio e la
gestione base, con esclusione di funzionalita' avanzate, personalizzazioni extra o strumenti
aggiuntivi richiesti successivamente dal Cliente.

**Esclusi** dal corrispettivo e a carico del Cliente:
- eventuali costi specifici di TikTok Shop
- costi di spedizione, logistica, packaging e gestione ordini
- connettori o integrazioni a pagamento con Danea EasyFatt
- costi imposti da Danea, TikTok, corrieri, marketplace o piattaforme terze
- campagne pubblicitarie a pagamento
- ogni costo straordinario non espressamente incluso

Dopo il primo anno, eventuali costi di rinnovo (dominio, Shopify, app/plugin, strumenti
collegati) potranno essere concordati separatamente.

## 4. Corrispettivo e modalita' di pagamento

**Euro 2.100,00 (duemilacento/00) al mese**, corrispettivo complessivo mensile dovuto dal
Cliente **indipendentemente dal soggetto che emette la fattura**.

- Fattura emessa il **primo giorno lavorativo di ogni mese**, da saldare **entro 15 giorni**
  dalla data di emissione, tramite bonifico bancario o altra modalita' concordata
- La fattura puo' essere emessa da Davide Cuelli o da Gabriel Palamini
- Nota fiscale: entrambi i soggetti fatturanti operano in regime forfettario ex art. 1
  commi 54-89 L. 190/2014. Le fatture **non sono soggette a IVA** ai sensi dell'art. 1 comma
  58 L. 190/2014 e **non sono soggette a ritenuta d'acconto**. Imposte di bollo applicate
  secondo normativa vigente.
- **Morosita'**: in caso di mancato pagamento nei termini, il Fornitore puo' sospendere
  l'erogazione di tutti i servizi, previo avviso scritto (anche via WhatsApp o email) con
  preavviso di 48 ore. La sospensione non costituisce inadempimento del Fornitore. I servizi
  riprendono all'avvenuto pagamento di tutte le somme dovute, compresi eventuali arretrati.

## 5. Durata e recesso

- Durata minima vincolante di **3 mesi** dalla data di firma, con decorrenza dei servizi
  dalla data di avvio lavori concordata
- Durante i 3 mesi **non e' previsto recesso anticipato da parte del Cliente**. In caso di
  interruzione anticipata, il Cliente e' tenuto al pagamento integrale dei mesi rimanenti a
  titolo di penale, per costi di setup, produzione e risorse gia' allocate
- Alla scadenza dei 3 mesi il Contratto si **rinnova tacitamente di mese in mese**, salvo
  disdetta scritta (anche email o WhatsApp) con almeno **30 giorni di preavviso** rispetto
  alla scadenza del mese in corso
- Il **Fornitore** puo' recedere in qualsiasi momento con preavviso scritto di 30 giorni,
  senza obbligo di motivazione, con rimborso proporzionale dei servizi non ancora erogati nel
  mese in corso

## 6. Obblighi del Cliente

- Fornire tempestivamente accessi, credenziali e materiali richiesti
- Designare un referente interno disponibile a rispondere entro i termini concordati
- Approvare o richiedere revisioni **entro 48 ore** dalla ricezione. Superato il termine
  senza risposta, **il contenuto si intende approvato**
- Non modificare, eliminare o alterare contenuti, impostazioni dello shop o configurazioni
  realizzate dal Fornitore senza preventivo accordo scritto
- Rispettare il calendario di pubblicazione concordato
- Pagare il corrispettivo nei termini dell'art. 4

## 7. Proprieta' intellettuale, contenuti e piattaforme

- I contenuti (video, copy, grafiche, struttura editoriale) sono di **proprieta' del Cliente
  a partire dal pagamento integrale del mese di riferimento**
- E-commerce, account, cataloghi prodotto e dati raccolti sono di proprieta' del Cliente. Il
  Fornitore ha accesso operativo limitato all'erogazione del servizio
- La consegna definitiva di materiali, configurazioni, accessi operativi o asset e'
  **subordinata al pagamento integrale** delle somme dovute
- Il Fornitore **si riserva il diritto di utilizzare i contenuti realizzati a fini di
  portfolio, case study e promozione** della propria attivita', salvo espressa indicazione
  contraria scritta del Cliente
- Il Cliente garantisce di possedere i diritti sui materiali forniti (loghi, foto,
  descrizioni prodotti) e solleva il Fornitore da responsabilita' in caso contrario

## 8. Limitazione di responsabilita'

- Il Fornitore **non e' responsabile dei risultati economici** dell'attivita' commerciale del
  Cliente, inclusi ricavi, conversioni e vendite generate tramite i canali digitali oggetto
  del Contratto
- Il Fornitore non e' responsabile di ritardi o limitazioni imposte da piattaforme terze
  (TikTok, Instagram, Shopify, Meta), ne' di modifiche alle loro policy
- Il Fornitore non risponde di danni indiretti, perdita di ricavi o danni reputazionali

## 9. Riservatezza

Le Parti mantengono riservate le informazioni commerciali, tecniche e finanziarie scambiate,
senza divulgarle a terzi senza consenso scritto dell'altra Parte.

## 10. Legge applicabile e foro competente

Legge italiana. **Foro esclusivo di Brescia**, con espressa rinuncia a qualsiasi altro foro.

## 11. Disposizioni finali

Il Contratto costituisce l'integrale accordo tra le Parti e sostituisce qualsiasi accordo,
intesa o comunicazione precedente, scritta o verbale. Modifiche concordate per iscritto
(anche email). La nullita' di una singola clausola non comporta la nullita' dell'intero
Contratto.

## Approvazione specifica clausole ex artt. 1341-1342 c.c.

Clausole che richiedono **seconda firma separata** del Cliente:

- **Art. 5** — durata minima 3 mesi, pagamento integrale dei mesi rimanenti in caso di
  recesso anticipato, rinnovo tacito mensile
- **Art. 4** — pagamento entro 15 giorni e diritto di sospendere i servizi in caso di morosita'
- **Art. 2 e 4** — co-fatturazione Davide Cuelli / Gabriel Palamini, importo complessivo non
  superiore a 2.100,00 euro
- **Art. 3.3** — natura **operativa e non garantita** dell'obiettivo di 1.000.000
  visualizzazioni, modalita' di calcolo e condizioni del supporto esteso gratuito
- **Art. 3.4** — costi esclusi a carico del Cliente
- **Art. 7** — accesso operativo limitato e consegna subordinata al pagamento integrale
- **Art. 8** — esclusione di responsabilita' per risultati economici, limitazioni di
  piattaforme terze e danni indiretti
- **Art. 10** — foro esclusivo di Brescia

Sezioni firma: Fornitore, Cliente, piu' firma separata del Cliente per l'approvazione
specifica. Data e luogo da compilare.
